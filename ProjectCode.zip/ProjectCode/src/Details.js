import React from 'react'
import {useParams,useLocation} from "react-router-dom"
export default function Details() {
    var params=useParams();
    var location=useLocation();
    console.log("location",location);
  return (
    <div>
        <h1>Details</h1>
        <h1>User Id :{params.userId}</h1>
        <h2>User Details: {JSON.stringify(location.state.selectedUser)}</h2>
        </div>
  )
}
