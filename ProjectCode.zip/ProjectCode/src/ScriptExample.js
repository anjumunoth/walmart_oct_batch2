// ES6 ECMA Script version 6 -- official name of js -- ES2015

// New features
//map method -- Use on an array

var arr1=[10,20,30,40,50]
var sqArr=[];
for(let i=0;i<arr1.length;i++)
{
    sqArr[i]=arr1[i]*arr1[i];
}

var squareArr=arr1.map(function (item){
    return item*item
})
map -- iterate through the elements of arr
1. Assign arr1[0] to item and execute the function
Return 100 and store it squareArr[0];

2. Assign arr1[1] to item and execute the function
Return 200 and store it squareArr[1];
....

console.log(squareArr);//[100,400,900,1600,2500]

map
-- Always be called on an array
-- Travese through the elements of the array and execute the function
-- size of resultant array = size of target array

var squareArrOfNumsGreaterThan30=arr1.map(function (item){
    if(item > 30)
    return item*item
})
console.log(squareArrOfNumsGreaterThan30);//[ud,ud,ud,1600,2500]
var i;
console.log(i);//undefined

function myFunc(p1,p2)
{
    return p1+p2;
}
myFunc(10,20);

var f1=function (p1,p2)
{
    return p1+p2;
}
var result=f1(10,20);
clg(result);//30

Use case of anonymous function
1. To pass a function as a param to another function
2. As a object key's value
var obj={
    empId:101,
    empName:"sara",
printDetails:function ()
{
    console.log("Emp Id"+ this.empId);
    console.log("Emp Name"+ this.empName);
}
}

obj.printDetails();//101; sara
clg(obj.empId);//101
clg(obj.101);//error
obj.displayData();//error

Lambda function -- fat arrow function
-- Special anonymous function
-- Lesser lines of code
-- "this" scope -- lexical scope


function myFunc(p1,p2)
{
    return p1+p2;
}
myFunc(10,20);

var f1=(p1,p2) => {
    return p1+p2;
};
f1(10,20);
var f1=p1 => {      return p1*p1;};

var f1=() => {      return "hello";};

var f1=(p1,p2) => p1+p2;
var empId=123;
var obj={
    empId:101,
    empName:"sara",
printDetails:function ()
{
    console.log("Emp Id"+ this.empId);// refer to the object on which function is called
    console.log("Emp Name"+ this.empName);
},
display:()=>{
    console.log("Inside FAF");// this -- lexical scope 
    console.log("Emp Id"+ this.empId);
}
}
obj.printDetails();//101 sara
obj.display();//"Inside FAF"; 123
var arr1=[10,20,30,40,50];
var squareArrOfNumsGreaterThan30=arr1.map((item)=>{
    if(item > 30)
    return item*item;
})
clg(squareArrOfNumsGreaterThan30);//[ud,ud,ud,1600,2500]
var arr1=[10,20,30,40,50];
var squareArr=arr1.map(item=> item*item);
clg(squareArr);//[100,400,900,1600,2500]



var emp={
    empId:101,empName:"sara"
}
var emp1=emp;//reference
emp1.empId=222
clg(emp);//{ empId:222,empName:"sara"}
clg(emp1);//{ empId:222,empName:"sara"}

// create a shallow copy
// ES6 feature -- spread operator
var emp2={...emp1};//copy
emp2.empId=333;
clg(emp2);//{ empId:333,empName:"sara"}
clg(emp1);//{ empId:222,empName:"sara"}

var emp3={...emp1,salary:5678};//copy
clg(emp3);//{ empId:222,empName:"sara",salary:5678}

var emp4={...emp1,empId:888};//copy
clg(emp4);//{ empId:888,empName:"sara"}

var emp5={empId:888,...emp1};//copy
clg(emp5);//{ empId:222,empName:"sara"}



/*
In .net
int i=5;
int i=7;

js:
var i=10;
var i=10;// no error

js : use strict 
var i=10;
var i=10;// error

const i=10;
i=11;//error

function myFunc(p1,p2)
{
    // pure function
    return p1+p2;
}

function myFunc1(p1,p2)
{
    //impure function
    return p1+p2+ Math.random();
    // request to the server -- same output is not guaranteed
}

myFunc(10,20);//30
myFunc(10,20);//30
myFunc1(10,20);//30.5
myFunc1(10,20);//30.2

*/




