import React, { Component } from 'react'

export class MyTimer extends Component {
    constructor()
    {
        super();
        this.state={currentTime:new Date(),
            clearIntervalId:0
        }
    }
    componentDidMount()
    {
        var clearIntervalId=setInterval(()=>{
            this.setState({currentTime: new Date()})
        },1000)
        this.setState({clearIntervalId:clearIntervalId})
        // request to the server
    }
    componentWillUnmount()
    {
        alert("Bye Timer unmounted")
        clearInterval(this.state.clearIntervalId);
    }
  render() {
    return (
      <div>
        <h1>MyTimer</h1>
            <h1>Time: {this.state.currentTime.toLocaleString()}</h1>
        </div>
    )
  }
}

export default MyTimer
