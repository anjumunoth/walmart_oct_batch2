import logo from './logo.svg';

import './App.css';

function App() {
  var h1Style={border:"5px solid red"};
  return (
    <div>
      <h1 style={h1Style}>Welcome to React</h1>
      <h2 style={ {border:"5px double blue"} }>Welcome to walmart</h2>
      <img src={logo} alt="React logo"/>
      <img src="./walmartLogo.jpg" alt="Walmart Logo" />
    </div>
  );
}

export default App;
/*
  App -- functional component
  -- return the virtual DOM

<h1 style="border: 5px solid red">Walmart </h1>
*/


