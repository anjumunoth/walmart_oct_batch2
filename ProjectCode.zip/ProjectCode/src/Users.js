import React,{useState,useEffect} from 'react'
import axios from 'axios';
import {useNavigate} from "react-router-dom";

function Users()
{
    var [companyName,setCompanyName]=useState("walmart")
    var [numberOfVisitors,setNumberOfVisitors]=useState(0);
    console.log("Hello");
    /*
    useState
    -- Take in the default value
    -- Return an array of only 2 elements
    -- companyName -- hold the value of the state -- data type --string 
    --setCompanyName -- modifying the companyName -- function
    --All the pointers about setState will hold good for setCompanyName
    -- modify the companyName, rerender the component -- execute the entire function again
    -- state(companyName) is maintained across updates
    */
    var changeCompanyEventHandler=()=>{
        setCompanyName("spring people");
    }
    var incNoOfVisitiorsEventHandler=()=>{
        setNumberOfVisitors((prevNumberOfVisitors)=>{
            return (prevNumberOfVisitors +1)
        })
    }
    var [usersArr,setUsersArr] =useState([]);
    useEffect(()=>{
        //mimic componentDidMount -- only once -- empty dependency array as second param
        var serverUrl="https://jsonplaceholder.typicode.com/users"
        axios.get(serverUrl)
        .then((response)=>{
                console.log("Response of get request",response)
            setUsersArr(response.data);
            
        })
        .catch((err)=>{
            console.log("error",err)
        })
    },[])
    var navigate=useNavigate();
    var detailsEventHandler=(selectedUser)=>{
        //navigate to the details Page
        navigate("/details/"+selectedUser.id,{state:{selectedUser:selectedUser}});
    }
    var liArr=usersArr.map(item =>{
        return (
            <li key={item.id}>
                {item.id} --- {item.name} -- {item.email} --
                <input type="button" value="Details" className='btn btn-primary'
                onClick={detailsEventHandler.bind(this,item)}
                />
            </li>
        )
    })
    
    return (
        <div>
            <h1>Users component</h1>
            <h1>Company Name: {companyName}</h1>
            <h1>Number of visitors: {numberOfVisitors}</h1>
            <input type="button" value="Change company name" className='btn btn-primary'
            onClick={changeCompanyEventHandler}
            />
            <input type="button" value="Inc number of visitors" className='btn btn-primary'
            onClick={incNoOfVisitiorsEventHandler}
            />
            {
                usersArr.length >0
                ? 
                <ul>
                    {liArr}
                </ul>
                :<h1>Loading ....</h1>
            }
        </div>
    );

}
export default Users;

/*
New ES^ feature

var i,j=10;
clg(i);//ud
var arr,arr1=[10,20,30];
clg(arr);//ud

var [first,second]=arr1
clg(first);//10
clg(second);//20

var [first,,third]=arr1
clg(third);//30

*/