import React, { Component } from 'react'
import AddToCart from './AddToCart';

export default class ProductsInfo extends Component {
  constructor()
  {
    super();
    //initialise the instance var
    this.ctr=0;
    // scope of this in the constructor -- component instance scope
    this.detailsEventHandler=this.detailsEventHandler.bind(this);
    this.reviewsEventHandler=this.reviewsEventHandler.bind(this);
    this.state={
      showAddToCart : false,
      selectedProduct:{},
      productsArr:[
        { productId: "p101", productName: "Apple Iphone", quantity: 22, price: 134567, productDesc: "Apple Iphone 13 pro max", imgUrl: "./images/iphone13.jpg" },
        { productId: "p102", productName: "Nokia", quantity: 2, price: 4567, productDesc: "Nokia basic phone", imgUrl: "./images/nokia.jpg" },
        { productId: "p103", productName: "One Plus 9", quantity: 5, price: 34567, productDesc: "One Plus 2 Nord ", imgUrl: "./images/oneplus9.jpg" },
        { productId: "p104", productName: "Google Pixel", quantity: 12, price: 31567, productDesc: "Google Pixel 2", imgUrl: "./images/pixel.jpg" },
        { productId: "p105", productName: "Samsung Fold", quantity: 18, price: 154567, productDesc: "Samsung Fold3", imgUrl: "./images/samsungFold3.jpg" },
      ]
    }
    

  }
  addToCartEventHandler=(selectedProduct)=>{
    // this -- lexical scope ; class scope; component scope
    console.log("Inside the addToCartEventHandler"+ this.ctr);// work 0
    //this.showAddToCart=true;
    // this.state.showAddToCart = true;// NO; will not call render implicitly
    this.setState({showAddToCart:true,selectedProduct:selectedProduct},()=>{
      console.log("Show add to cart",this.state.showAddToCart);//true  
    });
    //console.log("Show add to cart",this.state.showAddToCart);//false
  }

  detailsEventHandler=function(){
    // this -- object on which this function is called
    console.log("Inside details Event Handler"+ this.ctr);//this will not work
  }


  reviewsEventHandler()
  {
    console.log("Inside the reviewsEventHandler"+this.ctr);
  }
  onCancelConfirmationEventHandler=()=>{
    console.log("Inside Product Info");
    this.setState({showAddToCart:false});
  }
  onBuyConfirmationEventHandler=(cartObj)=>{
    // unmount AddToCart 
    
    // mutate the productsArr
    this.setState((prevState)=>{
      var pos= prevState.productsArr.findIndex(item => item.productId === cartObj.productId);
      if(pos >=0)
      {
        prevState.productsArr[pos].quantity -=cartObj.quantitySelected;
      }
      return ({
        productsArr:prevState.productsArr,
        showAddToCart:false
      })
    })

  }
  render() {
    console.log("Selected Product",this.state.selectedProduct);
    
    var cardsArr = this.state.productsArr.map(item => {
      return (
        <div key ={item.productId} className=' card bg-warning text-primary ' style={{ width: "18rem" }} >
          <img src={item.imgUrl} alt={item.productName} className='card-img-top' />
          <div className='card-body'>
            <h1 className='card-title'>{item.productName}</h1>
            <p className='card-title'>Quantity : {item.quantity}</p>
            <p className='card-title'>Price : {item.price}</p>
            <input type="button" value="Add To Cart" 
                onClick={()=>
                  {
                    this.addToCartEventHandler(item)
                  }
                }
                className='btn btn-primary m-2' />

            <input type="button" value="Details" 
                onClick={this.detailsEventHandler}
              className='btn btn-primary m-2' />

            <input type="button" value="Reviews" 
                onClick={this.reviewsEventHandler}
              className='btn btn-primary m-2' />
          </div>
        </div>

      )
    })

    return (
      <div>
        <h1>ProductsInfo</h1>
        <div className='container-fluid'>
          <div className='row'>
            {cardsArr}
          </div>
        </div>
        <div>
          
          {this.state.showAddToCart && 
          <AddToCart 
            companyName="walmart"
            selectedProduct={this.state.selectedProduct}
            onCancelConfirmation= {this.onCancelConfirmationEventHandler}
            onBuyConfirmation={this.onBuyConfirmationEventHandler}
          >
          </AddToCart>}
        </div>
      </div>
    )
  }
}


/*
<h1>Hello</h1>// fontsize : default 24px;
<h1 style="font-size: 1.5em;">Hi</h1>// fontsize : 24*1.5= 36px
<h1 style="font-size: 1.5rem;">Hi</h1>// fontsize : width of screen *1.5= 36px

Width of screen -- small devices, medium devices; large devices; xl devices


JSX 
-- No loops allowed 
-- No if else
-- No switch
Have to use loops but not explicitly -- map 

Dynamically rendered -- Rendered the jsx


In html
 <input type="button" value="Details" onclick="detailsEventHandler();" />
In JSX
synthetic events : wrapper around the normal html event
 <input type="button" value="Details" onClick={this.detailsEventHandler} />
detailsEventHandler -- has to written in the same component class outside the render function

Best practice for writing the event handler -- fat arrow function


class Employee
{

}

Employee emp1=new Employee(101,sara);
emp1.printDetails();

Conditional rendering:
1.ternary operator ?:
2.logical and -- short circuit
{this.showAddToCart ? <AddToCart></AddToCart> : null}
{this.showAddToCart && <AddToCart></AddToCart>}

var i=10,j=15,k=20;
if( i > j) && (++k > 25)
{
  clg("true")
}
else
{
  clg("false")
}
clg(k);// 20


var i=100;
console.log(i);// 100
i=200;

After display, changes to i has been made
i's updated value will not be displayed unless and until its explicitly done

Initial load of application:
virtual DOM created(showAddToCart --false )-- AddToCart -- will not be mounted
mapping virtual DOM -- real DOM

user clicked on AddTOCart -- event handler executed
memory showAddToCart -- true;
new virtual DOM returned with the changes;(call the render method again)
diffing algorithm


render 
-- called implicitly
-- called initially when the component is mounted after the constructor
-- lifecycle method 
-- Called multiple times during the lifecycle
-- Called explicitly -- NO
-- Call some other function(setState) which will internally call the render function

state
-- local mutable data of the component
-- Always in the object
-- Initialise it in the constructor
-- Mutate the state directly -- NO
-- Mutate the state using setState()

setState()
-- async method to mutate the state of component
-- 2 params ; 1st mandatory; 2nd -- optional
-- setState(obj/function, callback function)
-- obj as the first param -- merged with the existing state and merged obj becomes the new state
Replacement of the values
-- function as the first param -- return an object; returned object will be merged with the existing state and merged obj becomes the new state
Manipualate on basis of existing values
-- callback function; invoked implicitly when the setState has completed its operation
-- Tasks
1. Modify the state of the component
2. Call the render implicitly

function myFunc()
{
  clg("hello");
  setInterval(()=>{
    clg("welcome");
  },1000)
  clg("bye")
}
setInterval -- async function
myFunc();//hello; bye; welcome(after 1 sec)

update emp set salary=100 where empId=101;// Irrespective of its old value, salary =100

update emp set salary=salary +100 where empId=102;// Access the old value, increment by 100


Pass data from event to eventHandler
<input type="button" value="Add" onClick= {this.addEventHandler}/>
 onClick= {this.addEventHandler(item)};// NO will be invoked when the page loads

 1. onClick= {()=>{
  this.addEventHandler(item)
 }}

 2. onClick={this.addEventHandler.bind(this,item)}


 Pass data from parent to child
 Parent -- ProductInfo 
 Child -- AddToCart

 <a href="https://www.walmart.com" onclick="clickEventHandler();">Go To Walmart </a>
 Attributes :
 1. href -- Attribute/Property
 2. give some information to the tag so that the tag works correctly
 3. href -- mandatory; class, id , style -- optional
 4. Write the attributes -- as part of opening tag of element
 5. Can have data or be events and event handlers


*/