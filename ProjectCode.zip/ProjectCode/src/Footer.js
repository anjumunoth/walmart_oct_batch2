import React from "react";

class Footer extends React.Component
{
    render()
    {
        //return the virtual DOM
        return(
            <div className="container-fluid">
                <div className="row">
                    <a className="offset-2 col-1" >Private and Security</a>
                    <a className="col-1" >CA Privacy rights</a>
                </div>
                
            </div>
            
        )
    }
}

export default Footer;

