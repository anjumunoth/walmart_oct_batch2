import React, { Component } from 'react'
import MyTimer from './MyTimer';

class AddToCart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            quantitySelected: 1,
            ctr: 1,
            productId: this.props.selectedProduct.productId

        }
    }
    static getDerivedStateFromProps(newProps, prevState) {
        if (newProps.selectedProduct.productId !== prevState.productId) {
            console.log(" getDerivedStateFromProps called");
            return ({
                ...prevState, quantitySelected: 1,productId:newProps.productId
            })
        }
        else
        {
            return ({...prevState});
        }
    }
    changeQuantityEventHandler = (strOp) => {
        if (strOp === "dec") {
            //this.setState({quantitySelected:this.state.quantitySelected - 1})
            if (this.state.quantitySelected > 1) {
                this.setState((prevState) => {
                    return (
                        { quantitySelected: prevState.quantitySelected - 1 }
                    )
                })
            }
        }
        else {
            //this.setState({quantitySelected:this.state.quantitySelected + 1})
            if (this.state.quantitySelected < this.props.selectedProduct.quantity) {
                this.setState((prevState) => {
                    return ({
                        quantitySelected: prevState.quantitySelected + 1
                    })
                })
            }
        }
    }
    buyEventHandler = () => {
        var cartObj = { ...this.props.selectedProduct, quantitySelected: this.state.quantitySelected };
        // trigger an event -- pass some data (cartObj)
        this.props.onBuyConfirmation(cartObj);
        // navigate to the payments page

    }
    cancelEventHandler = () => {
        // trigger a custom event
        this.props.onCancelConfirmation();
    }
    render() {
        console.log("Selected Product in Add To cart", this.props.selectedProduct)
        var item = { ...this.props.selectedProduct };
        return (
            <div>
                <h1>AddToCart</h1>
                <MyTimer></MyTimer>
                <h1>Ctr : {this.state.ctr}</h1>
                <h1> {this.props.companyName}</h1>
                <div className='container'>
                    <div className='row'>
                        <div key={item.productId} className='col-4 offset-4 card bg-primary text-warning '  >
                            <img src={item.imgUrl} alt={item.productName} className='card-img-top' />
                            <div className='card-body'>
                                <h1 className='card-title'>{item.productName}</h1>
                                <p className='card-title'>Quantity : {item.quantity}</p>
                                <p className='card-title'>Price : {item.price}</p>
                                <input type="button" value="-" className='btn btn-warning m-2'
                                    disabled={this.state.quantitySelected <= 1}
                                    onClick={() => {
                                        this.changeQuantityEventHandler("dec")
                                    }} />
                                <span>{this.state.quantitySelected}</span>
                                <input type="button" value="+" className='btn btn-warning m-2'
                                    disabled={this.state.quantitySelected >= this.props.selectedProduct.quantity}
                                    onClick={() => {
                                        this.changeQuantityEventHandler("inc")
                                    }} />
                                <br />
                                <input type="button" value="Buy" className='btn btn-success m-2' onClick={this.buyEventHandler} />
                                <input type="button" value="Cancel" className='btn btn-danger m-2' onClick={this.cancelEventHandler} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default AddToCart

/*
Props 
-- data coming from the parent
-- Immutable data of the component
-- 

On click of cancel button (AddToCart) -- unmount AddToCart component

Mount the AddToCart component:
showAddToCart(ProductInfo ) -- changed it to true -- setState()
1. Modify the state of ProductInfo --showAddToCart -- true
2. call the render of ProductInfo again 
2.a AddToCart will be mounted; constructor and render of AddToCart will be executed
3. If callback present, callback will be executed

Unmount the AddToCart component: -- by clicking the cancel button (AddToCart)
trigger an event in the parent component-- corresponding event handler will be executed
showAddToCart(ProductInfo ) -- changed it to false-- setState()
1. Modify the state of ProductInfo --showAddToCart -- false
2. call the render of ProductInfo again 
2.a AddToCart will be unmounted(if it is mounted);
 componentWillUnmount of AddToCart will be executed
3. If callback present, callback will be executed


Child to parent communication:
Events and event handlers

Sample Component:
<input type="button" value="Add" onClick={this.addEventHandler} />

1. input tag is present -- Sample component
2. addEventHandler -- within Sample component outside the render
3. onClick -- synthetic event ; On trigger of the event, handler gets invoked implicitly
4. Trigger the event ; user click on button

Replace Sample component with parent
Replace input tag with the child
parent -- ProductInfo
child -- AddToCart







*/