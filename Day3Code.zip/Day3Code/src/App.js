import logo from './logo.svg';
import Header from "./Header";
import Footer from "./Footer";

import './App.css';
import ProductsInfo from './ProductsInfo';

function App() {
  return (
    <div>
      <Header></Header>
      <ProductsInfo></ProductsInfo>
      <Footer></Footer>
    </div>
  );
}

export default App;
/*
  App -- functional component
  -- return the virtual DOM

<h1 style="border: 5px solid red">Walmart </h1>
*/


