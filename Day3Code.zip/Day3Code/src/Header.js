import React from "react";

//class component
class Header extends React.Component {
    // render -- mandatory -- return the virtual DOM
    render() {
        return (
            <div className="container-fluid">
                <div className="bg-warning text-primary row text-center align-items-center">
                    <img className="col-4" src="./images/walmartLogo.jpg" alt="walmart Logo" />
                    <h1 className="col-8">Walmart Shopping</h1>
                   
                </div>
            </div>
        )
    }
}

export default Header;
/*
Bootstrap -- browser specific 
primary -- blue
success -- green
warning -- yellow
danger -- red
secondary -- grey
white -- white
info -- cyan

grid layout -- rows and columns
Each row - 12 columns

Container
Rows
Col -- how many columns

Container
Row
h1 -- 8 columns
img -- 4 columns

*/